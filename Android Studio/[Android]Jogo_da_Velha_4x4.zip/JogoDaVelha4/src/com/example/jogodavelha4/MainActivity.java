package com.example.jogodavelha4;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	//const. da tag de cada botao
	//utilizamos essa const. para recuperar o botao atraves do metodos getQuadrado
	private final String QUADRADO = "quadrado";
	//const. que vai ser impressa no text do botao
	private final String BOLA	= "O";
	//const. que vai ser impressa no text do botao
	private final String XIS	= "X";
	
	private String lastPlay = "X";
	
	private View view;
	
	int[][] estadoFinal = new int[][] {

		{1,2,3,4},
		{5,6,7,8},
		{9,10,11,12},
		{13,14,15,16},
		
		{1,5,9,13},
		{2,6,10,14},
		{3,7,11,15},
		{4,8,12,16},
		
		{1,6,11,16},
		{4,7,10,13},
		
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setView(getLayoutInflater().inflate(R.layout.activity_main, null));
		setContentView(getView());
	}

	public void clickQuadrado(View v) {
		
		if(!isFim()) {
			if(((Button)v).getText().equals("")) {
				
				if(getLastPlay().equals(XIS)) {
					((Button)v).setText(BOLA);	
					setLastPlay(BOLA);
					TextView text = (TextView)this.findViewById(R.id.textView1);
					text.setText("Vez do jogador X"); 
					
				}else {
					
					((Button)v).setText(XIS);		
					setLastPlay(XIS);
					TextView text = (TextView)this.findViewById(R.id.textView1);
					text.setText("Vez do jogador O"); 
					
				}			
			}else {
				Toast.makeText(getView().getContext(), "Escolha outro quadrado", Toast.LENGTH_LONG).show();	
			}
			isFim();
		}
	}
	
	public Button getQuadrado(int tagNum) {
		return (Button)getView().findViewWithTag(QUADRADO+tagNum);
	}
	
	public void newGame(View v) {
		
		setEnableQuadrado( true );
		setColorBlack();
		
		for(int i=1; i<=16; ++i) {
			if(getQuadrado(i) != null) {
				getQuadrado(i).setText("");
			}
		}
		
		RadioButton rX = (RadioButton)getView().findViewById(R.id.rbX);
		RadioButton rO = (RadioButton)getView().findViewById(R.id.rbO);
		
		if(rX.isChecked()) {
			setLastPlay(BOLA);
		}else {
			if(rO.isChecked()) {
				setLastPlay(XIS);
			}
		}
		TextView text = (TextView)this.findViewById(R.id.textView1);
		text.setText(""); 
	}
	
	public void setEnableQuadrado(boolean b) {
		for(int i=1; i<=16; ++i) {
			if(getQuadrado(i)!=null) {
				getQuadrado(i).setEnabled(b);
			}
		}
	}
	
	public void setColorQuadrados( int btn, int coloX) {
		
		getQuadrado( btn ).setTextColor(getResources().getColor(coloX));
	}
	
	public void setColorBlack() {
		for(int i = 1; i<=16; ++i) {
			if(getQuadrado(i)!=null) {
				setColorQuadrados(i, R.color.black);
			}
		}
	}
	
	public boolean isFim() {
		
		for(int x=0; x<=9; ++x) {

			String s1 = getQuadrado(estadoFinal[x][0]).getText().toString();
			String s2 = getQuadrado(estadoFinal[x][1]).getText().toString();
			String s3 = getQuadrado(estadoFinal[x][2]).getText().toString();
			String s4 = getQuadrado(estadoFinal[x][3]).getText().toString();
			
			if(	(!s1.equals(""))&&
				(!s2.equals(""))&&
				(!s3.equals(""))&&
				(!s4.equals(""))
					) {
				if((s1.equals(s2))&&(s2.equals(s3))&&(s3.equals(s4))) {
					setColorQuadrados(estadoFinal[x][0], R.color.red );
					setColorQuadrados(estadoFinal[x][1], R.color.red );
					setColorQuadrados(estadoFinal[x][2], R.color.red );
					setColorQuadrados(estadoFinal[x][3], R.color.red );
					Toast.makeText(getView().getContext(), "Fim de jogo", Toast.LENGTH_LONG).show();

					if(getLastPlay().equals(XIS)) {
						TextView text = (TextView)this.findViewById(R.id.textView1);
						text.setText("Jogador X venceu!"); 
						
					}else {
						TextView text = (TextView)this.findViewById(R.id.textView1);
						text.setText("Jogador O venceu!"); 
						
					}			
					
					
					return true;
					}
				}
			}
		
		return false;
		
	}
	
	public View getView() {
		return view;
	}

	public void setView(View view) {
		this.view = view;
	}
	
	

	public String getLastPlay() {
		return lastPlay;
	}

	public void setLastPlay(String lastPlay) {
		this.lastPlay = lastPlay;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
