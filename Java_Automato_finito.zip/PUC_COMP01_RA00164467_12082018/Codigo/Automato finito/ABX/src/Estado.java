
public interface Estado {
	public Estado wayA(Estado current);

	public Estado wayB(Estado current);

	public Estado wayX(Estado current);
}
