import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Start {
	public static void main(String[] arg) {
		BufferedReader buffer = new BufferedReader(new InputStreamReader(System.in));
		
		String c;
		String str = "";
		String unity = "";	
		Estado currentState = new q0();
		
		System.out.println("Digite a entrada");
		try {
			str = buffer.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Output :" + str);
		
		String[] strArray = str.split("");

		for(int i=0; i<strArray.length ;i++) {
			c = strArray[i];
			unity = unity + c;
			System.out.println(unity);

			switch(c) {
				case "a":
					currentState = currentState.wayA(currentState);
					break;
			}
			switch(c) {
				case "b":
					currentState = currentState.wayB(currentState);
					break;
			}
			switch(c) {
				case "x":
					currentState = currentState.wayX(currentState);
					break;
			}
		}
		
		return;
	}
}