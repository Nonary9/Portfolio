
public class Estados {

}

class q0 implements Estado{

	@Override
	public Estado wayA(Estado current) {
		current = new q1();
		return current;
	}

	@Override
	public Estado wayB(Estado current) {
		current = new q0();
		return current;
	}

	@Override
	public Estado wayX(Estado current) {
		current = new q5();
		return current;
	}
	
}
class q1 implements Estado{

	@Override
	public Estado wayA(Estado current) {
		current = new q2();
		return current;
	}

	@Override
	public Estado wayB(Estado current) {
		current = new q0();
		return current;
	}

	@Override
	public Estado wayX(Estado current) {
		current = new q5();
		return current;
	}
	
}
class q2 implements Estado{

	@Override
	public Estado wayA(Estado current) {
		current = new q2();
		return current;
	}

	@Override
	public Estado wayB(Estado current) {
		current = new q3();
		return current;
	}

	@Override
	public Estado wayX(Estado current) {
		current = new q5();
		return current;
	}
	
}
class q3 implements Estado{

	@Override
	public Estado wayA(Estado current) {
		current = new q1();
		return current;
	}

	@Override
	public Estado wayB(Estado current) {
		current = new q4();
		System.out.println("Sequencia 'aabb' detectado");
		return current;
	}

	@Override
	public Estado wayX(Estado current) {
		current = new q5();
		return current;
	}
	
}
class q4 implements Estado{

	@Override
	public Estado wayA(Estado current) {
		current = new q1();
		return current;
	}

	@Override
	public Estado wayB(Estado current) {
		current = new q0();
		return current;
	}

	@Override
	public Estado wayX(Estado current) {
		current = new q5();
		return current;
	}
	
}
class q5 implements Estado{

	@Override
	public Estado wayA(Estado current) {
		current = new q1();
		return current;
	}

	@Override
	public Estado wayB(Estado current) {
		current = new q0();
		return current;
	}

	@Override
	public Estado wayX(Estado current) {
		current = new q6();
		return current;
	}
	
}
class q6 implements Estado{

	@Override
	public Estado wayA(Estado current) {
		current = new q1();
		return current;
	}

	@Override
	public Estado wayB(Estado current) {
		current = new q0();
		return current;
	}

	@Override
	public Estado wayX(Estado current) {
		current = new q7();
		
		try {
			throw new Exception("Sequencia 'xxx': erro detectado");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return current;
	}
	
}
class q7 implements Estado{

	@Override
	public Estado wayA(Estado current) {
		current = new q1();
		return current;
	}

	@Override
	public Estado wayB(Estado current) {
		current = new q0();
		return current;
	}

	@Override
	public Estado wayX(Estado current) {
		current = new q5();
		return current;
	}
	
}